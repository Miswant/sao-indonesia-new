@include('head')
@include('header')
<section id="cta" class="cta">
        <div class="section-header">
          <h2></h2>
          <p></p>
        </div>
      <div class="container" data-aos="zoom-out">
      

        <div class="row g-5">

          <div class="col-lg-6 col-md-6 content d-flex flex-column justify-content-center order-last order-md-first">
          <p><strong>Multi Cabang</strong></p>
            <h3>Kendalikan Setiap <em>Cabang</em> dengan Kepastian Penuh</h3>
                  <p><i class="bi bi-check2"></i> Pertajam Efisiensi dengan Otomatisasi Pencatatan dan Analisa Multi Outlet.</p>
                  <p><i class="bi bi-check2"></i> Efisiensi Tinggi dan Pengawasan Maksimal dalam Bisnis Multi Cabang.</p>
           <a class="cta-btn align-self-start" href="#" onclick="openChat()">Hubungi Kami</a>
          </div>

          <div class="col-lg-6 col-md-6 order-first order-md-last d-flex align-items-center">
            <div class="img">
              <img src="assets/img/skala-bisnis/multi-cabang.png" alt="" class="img-fluid">
            </div>
          </div>

        </div>

      </div>
    </section>
@include('footer')
@include('script')