@include('head')
@include('header')
<section id="cta" class="cta">
        <div class="section-header">
          <h2></h2>
          <p></p>
        </div>
      <div class="container" data-aos="zoom-out">
      

        <div class="row g-5">

          <div class="col-lg-6 col-md-6 content d-flex flex-column justify-content-center order-last order-md-first">
          <p><strong></strong></p>
            <h3>Integrasi Berbagai <em>Modul </em></h3>
                  <p><i class="bi bi-check2"></i> Aplikasi SAO mengintegrasikan berbagai modul fungsional seperti akuntansi, manajemen stok, manajemen produksi, sumber daya manusia, keuangan, penjualan, pembelian, distribusi, dan lain-lain.</p>
                  <p><i class="bi bi-check2"></i> Integrasi ini memungkinkan informasi bergerak dengan lancar antar departemen.</p>
           <a class="cta-btn align-self-start" href="#" onclick="openChat()">Hubungi Kami</a>
          </div>

          <div class="col-lg-6 col-md-6 order-first order-md-last d-flex align-items-center">
            <div class="img">
              <img src="assets/img/fiturSAO/integrasi.png" alt="" class="img-fluid">
            </div>
          </div>

        </div>

      </div>
    </section>
@include('footer')
@include('script')