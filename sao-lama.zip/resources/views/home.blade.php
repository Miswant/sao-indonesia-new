<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>SAO Indonesia</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/saologo.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,600;1,700&display=swap"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Variables CSS Files. Uncomment your preferred color scheme -->
    <link href="assets/css/variables.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
    <!-- Bootstrap Icons CSS -->


</head>


<body>

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
        <div class="container d-flex align-items-center">

            <h1 class="logo me-auto"><a href="#">Sale Account Organizer</a></h1>
            <!-- Uncomment below if you prefer to use an image logo -->
            <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

            <nav id="navbar" class="navbar">

                <ul>
                    <li class="nav-item"><a class="nav-link scrollto active" href="#hero-animated" style=""
                            aria-current="page">Home</a></li>
                    {{-- <li><a class="nav-link scrollto" href="#about">About</a></li> --}}
                    <li class="nav-item"><a class="nav-link scrollto" href="#clients">Clients</a></li>
                    <li class="nav-item"><a class="nav-link scrollto" href="#services">Services</a></li>
                    <li class="nav-item"><a class="nav-link scrollto" href="#pricing">Contoh Module</a></li>
                    <!-- <li class="nav-item"><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li> -->
                    {{-- <li class="nav-item"><a class="nav-link scrollto" href="#team">Team</a></li>
                            <li class="dropdown"><a href="#"><span>Drop Down</span> <i
                                        class="bi bi-chevron-down"></i></a>
                                <ul>
                                    <li><a href="#">Drop Down 1</a></li>
                                    <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i
                                                class="bi bi-chevron-right"></i></a>
                                        <ul>
                                            <li><a href="#">Deep Drop Down 1</a></li>
                                            <li><a href="#">Deep Drop Down 2</a></li>
                                            <li><a href="#">Deep Drop Down 3</a></li>
                                            <li><a href="#">Deep Drop Down 4</a></li>
                                            <li><a href="#">Deep Drop Down 5</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Drop Down 2</a></li>
                                    <li><a href="#">Drop Down 3</a></li>
                                    <li><a href="#">Drop Down 4</a></li>
                                </ul>
                            </li> --}}
                    <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
                </ul>
                {{-- <i class="bi bi-list mobile-nav-toggle" data-bs-toggle="collapse" data-bs-target="#navbar"></i> --}}


            </nav><!-- .navbar -->



        </div>
    </header><!-- End Header -->



    <style>
        #navbar ul li a.nav-link {
            color: white;
            /* Change this to the desired color code */
        }

        /* Change the color of active link */
        #navbar ul li a.nav-link.active {
            color: white;
            /* Change this to the desired color code for the active link */
        }

        /* Style untuk tampilan desktop */
        .img-fluid-desktop {
            max-width: 50%;
            height: auto;
        }

        /* Style untuk tampilan mobile */
        @media (max-width: 767px) {
            .img-fluid-desktop {
                display: none;
                /* Menyembunyikan gambar pada tampilan mobile */
            }

            .sao-logo {
                max-width: 100%;
                height: auto;
                margin: 0 auto;
                display: block;
                position: center;
            }

        }
    </style>

    <!-- ======= Hero Section ======= -->
    <section id="hero-animated" class="hero-animated d-flex align-items-center">

        <div class="container d-flex flex-column justify-content-center align-items-start text-center position-relative"
            data-aos="zoom-out">
            <div class="d-flex flex-row-reverse">
                <img src="assets/img/hero-carousel/smartmockups_po.png"
                    class="img-fluid img-fluid-desktop animated" style="max-width: 50%; height: auto;">
                <div>
                    <h2></h2>
                    <p></p>
                    <div class="d-flex">
                        <!-- <a href="#about" class="btn-get-started scrollto">Get Started</a>
                  <a href="https://www.youtube.com/watch?v=LXb3EKWsInQ" class="glightbox btn-watch-video d-flex align-items-center"><i class="bi bi-play-circle"></i><span>Watch Video</span></a> -->
                    </div>
                    <h2>ONE TOUCH FOR ALL</h2>
                    <img src="assets/img/saologo.png" alt="" class="sao-logo">
                    <h3>(Sale Account Organizer)</h3>
                </div>
            </div>
        </div>

    </section><!-- End Hero -->

    <main id="main">
        <!-- ======= Clients Section ======= -->
        <section id="clients" class="hero">
            <div class="container">

                <div class="row" data-aos="zoom-in">

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/abs.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/alfatech.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/btp.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/bts.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/dwp.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/ecclesia.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/g.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/gitaperkasa.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/logo-removebg-preview.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/map.jpg" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/mbi.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/optima.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/penta.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/pjp.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/ramayanamotor.png" class="img-fluid" alt=""></div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/rodajaya.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/sevenmountain.png" class="img-fluid" alt=""></div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/stthbi.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/superban.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/tatawisata.png" class="img-fluid" alt=""></div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/triboga.png" class="img-fluid" alt=""></div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/vav.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center"><img
                            src="assets/img/clients/wilson.png" class="img-fluid" alt="">
                    </div>
                </div>

            </div>
        </section><!-- End Cliens Section -->

        <!-- ======= About Us Section ======= -->
        <!-- ======= Services Section ======= -->
        <section id="services" class="services section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>MENGAPA ANDA HARUS MENGGUNAKAN SALE ACCOUNT ORGANIZER?</h2>
                    <p>Kenapa SAO Indonesia menjadi pilihan yang tepat untuk membantu aktivitas akuntansi dan penjualan
                        bisnis Anda?</p>
                </div>

                <div class="row">
                    <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in"
                        data-aos-delay="100">
                        <div class="icon-box">
                            <div class="icon"><i class="bi bi-book icon"></i></div>
                            <h4><a href="">CEPAT DAN MUDAH DIPAHAMI</a></h4>
                            <p>Program kami cukup mudah dipahami sehingga karyawan Anda dapat belajar menggunakannya
                                dalam
                                hitungan menit.</p>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in"
                        data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon"><i class="bi bi-journal-check icon"></i></div>
                            <h4><a href="">LAPORAN LENGKAP</a></h4>
                            <p>Sale Account Organizer dapat dengan cepat menyusun dan menyajikan data penting tentang
                                kehidupan bisnis sehari-hari perusahaan Anda dengan salah satu dari banyak program
                                pembuatan
                                laporannya.</p>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in"
                        data-aos-delay="300">
                        <div class="icon-box">
                            <div class="icon"><i class="bi bi-bar-chart icon"></i></div>
                            <h4><a href="">MANAJEMEN SAHAM MUDAH</a></h4>
                            <p>Lacak terus pergerakan saham perusahaan Anda sebagai bagian dari operasi sehari-hari,
                                atau
                                ubah sendiri catatan saham Anda.</p>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in"
                        data-aos-delay="400">
                        <div class="icon-box">
                            <div class="icon"><i class="bx bx-dollar-circle"></i></div>
                            <h4><a href="">OPTIMIZASI KEUANGAN</a></h4>
                            <p>Sale Account Organizer membantu mengoptimalkan pengelolaan keuangan perusahaan Anda
                                dengan berbagai fitur yang mudah digunakan.</p>
                        </div>
                    </div>

                </div>

            </div>
        </section><!-- End Services Section -->
        <!-- ======= About Section ======= -->
        {{-- <section id="about" class="about">
            <div class="container" data-aos="fade-up">

                <!-- <div class="section-header">
        <h2>About Us</h2>
        <p>Architecto nobis eos vel nam quidem vitae temporibus voluptates qui hic deserunt iusto omnis nam voluptas asperiores sequi tenetur dolores incidunt enim voluptatem magnam cumque fuga.</p>
      </div> -->

                <div class="row g-4 g-lg-5" data-aos="fade-up" data-aos-delay="200">

                    <!-- <div class="col-lg-7">
          <div class="about-img">
            <img src="assets/img/akutansi/kas-masuk.png" class="img-fluid" alt="">
          </div>
        </div> -->

                    <div class="col-lg-12">
                        <h3 class="pt-0 pt-lg-5">Software ERP (Enterprise Resource Planning) online untuk segala
                            kebutuhan
                            bisnis</h3>

                        <!-- Tabs -->
                        <ul class="nav nav-pills mb-6">
                            <li><a class="nav-link active" data-bs-toggle="pill" href="#tab1">Operasional
                                    keuangan</a>
                            </li>
                            <li><a class="nav-link" data-bs-toggle="pill" href="#tab2">Manajemen inventori &
                                    gudang</a>
                            </li>
                            <li><a class="nav-link" data-bs-toggle="pill" href="#tab3">Perencanaan & analisa
                                    keuangan</a></li>
                        </ul><!-- End Tabs -->

                        <!-- Tab Content -->
                        <div class="tab-content">

                            <div class="tab-pane fade show active" id="tab1">
                                <div class="d-flex align-items-center mt-4">
                                    <i class="bi bi-check2"></i>
                                    <h4>Optimalkan operasi untuk tingkatkan profit</h4>
                                </div>
                                <p>Kelola arus kas, invoice, dan pengeluaran lebih mudah untuk pastikan pembayaran tepat
                                    waktu dan buat anggaran ideal.</p>
                                <!-- <img src="assets/img/akutansi/kas-masuk.png" > -->
                            </div><!-- End Tab 1 Content -->

                            <div class="tab-pane fade show" id="tab2">
                                <div class="d-flex align-items-center mt-4">
                                    <i class="bi bi-check2"></i>
                                    <h4>Rancang strategi terbaik untuk efisiensi gudang</h4>
                                </div>
                                <p><i class="bi bi-check2"></i> Fitur ini membantu dalam melacak stok barang secara
                                    real-time, melakukan perhitungan persediaan, mengoptimalkan pembelian, dan
                                    menghindari kekurangan stok atau kelebihan stok.</p>
                                <!-- <img src="assets/img/akutansi/kas-masuk.png" > -->
                            </div><!-- End Tab 2 Content -->

                            <div class="tab-pane fade show" id="tab3">
                                <div class="d-flex align-items-center mt-4">
                                    <i class="bi bi-check2"></i>
                                    <h4>Insight berharga untuk optimalkan strategi keuangan</h4>
                                </div>
                                <p>Pahami kondisi bisnis dengan mudah melalui beragam fitur yang memudahkan analisa
                                    laporan
                                    keuangan.</p>
                                <!-- <img src="assets/img/akutansi/kas-masuk.png" > -->
                            </div><!-- End Tab 3 Content -->

                        </div>

                    </div>

                </div>

            </div>
        </section><!-- End About Section --> --}}

        <!-- ======= About Section ======= -->
        <section id="about" class="about">
            <div class="container" data-aos="fade-up">

                <!-- <div class="section-header">
        <h2>About Us</h2>
        <p>Architecto nobis eos vel nam quidem vitae temporibus voluptates qui hic deserunt iusto omnis nam voluptas asperiores sequi tenetur dolores incidunt enim voluptatem magnam cumque fuga.</p>
      </div> -->

                <div class="row g-4 g-lg-5" data-aos="fade-up" data-aos-delay="200">

                    <!-- <div class="col-lg-7">
          <div class="about-img">
            <img src="assets/img/akutansi/kas-masuk.png" class="img-fluid" alt="">
          </div>
        </div> -->

                    <div class="col-lg-12">
                        <div class="section-title">
                            <h2>FITUR SAO (Sale Account Organizer)</h2>
                        </div>
                        {{-- <h3 class="pt-0 pt-lg-5">FITUR SAO (Sale Account Organizer)</h3> --}}

                        <!-- Tabs -->
                        <ul class="nav nav-pills mb-6">
                            <li><a class="nav-link active" data-bs-toggle="pill" href="#tab1">Integrasi Berbagai
                                    <em>Modul </em></a>
                            </li>
                            <li><a class="nav-link" data-bs-toggle="pill" href="#tab2">Manajemen stok dan
                                    <em>Persediaan </em></a>
                            </li>
                            <li><a class="nav-link" data-bs-toggle="pill" href="#tab3">Akutansi dan <em>keuangan
                                    </em></a></li>
                        </ul><!-- End Tabs -->

                        <!-- Tab Content -->
                        <div class="tab-content">

                            <div class="tab-pane fade show active" id="tab1">


                                <div class="row g-5">

                                    <div
                                        class="col-lg-6 col-md-6 content d-flex flex-column justify-content-center order-last order-md-first">
                                        <p><strong></strong></p>
                                        <h3>Integrasi Berbagai <em>Modul </em></h3>
                                        <p><i class="bi bi-check2"></i> Aplikasi SAO mengintegrasikan berbagai
                                            modul fungsional seperti akuntansi, manajemen stok, manajemen produksi,
                                            sumber daya manusia, keuangan, penjualan, pembelian, distribusi, dan
                                            lain-lain.</p>
                                        <p><i class="bi bi-check2"></i> Integrasi ini memungkinkan informasi
                                            bergerak dengan lancar antar departemen.</p>
                                        <a class="cta-btn align-self-start" href="#"
                                            onclick="openChat()">Hubungi Kami</a>
                                    </div>

                                    <div class="col-lg-6 col-md-6 order-first order-md-last d-flex align-items-center">
                                        <div class="img">
                                            <img src="assets/img/fiturSAO/integrasi.png" alt=""
                                                class="img-fluid">
                                        </div>
                                    </div>

                                </div>

                                {{-- </div>
                                </div> --}}
                                <!-- <img src="assets/img/akutansi/kas-masuk.png" > -->
                            </div><!-- End Tab 1 Content -->

                            <div class="tab-pane fade show" id="tab2">
                                <div class="row g-5">

                                    <div
                                        class="col-lg-6 col-md-6 content d-flex flex-column justify-content-center order-last order-md-first">
                                        <p><strong></strong></p>
                                        <h3>Manajemen stok dan <em>Persediaan </em></h3>
                                        <p><i class="bi bi-check2"></i> Fitur ini membantu dalam melacak stok barang
                                            secara real-time, melakukan perhitungan persediaan, mengoptimalkan
                                            pembelian, dan menghindari kekurangan stok atau kelebihan stok.</p>
                                        <a class="cta-btn align-self-start" href="#"
                                            onclick="openChat()">Hubungi Kami</a>
                                    </div>

                                    <div class="col-lg-6 col-md-6 order-first order-md-last d-flex align-items-center">
                                        <div class="img">
                                            <img src="assets/img/fiturSAO/manajemen-stock.png" alt=""
                                                class="img-fluid">
                                        </div>
                                    </div>

                                </div>
                                <!-- <img src="assets/img/akutansi/kas-masuk.png" > -->
                            </div><!-- End Tab 2 Content -->

                            <div class="tab-pane fade show" id="tab3">
                                <div class="row g-5">

                                    <div
                                        class="col-lg-6 col-md-6 content d-flex flex-column justify-content-center order-last order-md-first">
                                        <p><strong></strong></p>
                                        <h3>Akutansi dan <em>keuangan </em></h3>
                                        <p><i class="bi bi-check2"></i> Modul ini membantu dalam pelacakan transaksi
                                            keuangan, pembayaran, faktur, laporan keuangan, dan pembuatan anggaran.</p>
                                        <a class="cta-btn align-self-start" href="#"
                                            onclick="openChat()">Hubungi Kami</a>
                                    </div>

                                    <div class="col-lg-6 col-md-6 order-first order-md-last d-flex align-items-center">
                                        <div class="img">
                                            <img src="assets/img/fiturSAO/akutansi.png" alt=""
                                                class="img-fluid">
                                        </div>
                                    </div>

                                </div>
                                <!-- <img src="assets/img/akutansi/kas-masuk.png" > -->
                            </div><!-- End Tab 3 Content -->

                        </div>

                    </div>

                </div>

            </div>
        </section><!-- End About Section -->

        <!-- ======= Features Section ======= -->
        <section id="pricing" class="pricing">
            <div class="container" data-aos="fade-up">
            </div>
        </section>
        <section id="features" class="features">
            <div class="section-title">
                <h2>Contoh Module</h2>
            </div>
            <div class="container" data-aos="fade-up">

                <ul class="nav nav-tabs row gy-4 d-flex">

                    <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#tab-1">
                            <h4>Menu Login</h4>
                        </a>
                    </li>
                    <!-- End Tab 1 Nav -->

                    <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2">
                            <h4>Master Supplier</h4>
                        </a>
                    </li>
                    <!-- End Tab 2 Nav -->

                    <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3">
                            <h4>Purchase Order</h4>
                        </a>
                    </li>
                    <!-- End Tab 3 Nav -->

                    <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4">
                            <h4>Sales Order</h4>
                        </a>
                    </li>
                    <!-- End Tab 4 Nav -->

                    <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5">
                            <h4>Bank Masuk</h4>
                        </a>
                    </li>
                    <!-- End Tab 5 Nav -->

                    <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6">
                            <h4>Laporan Keuangan</h4>
                        </a>
                    </li>
                    <!-- End Tab 6 Nav -->

                    <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-7">
                            <h4>Menu-menu lainya</h4>
                        </a>
                    </li>
                    <!-- End Tab 7 Nav -->

                    <!-- <li class="nav-item col-6 col-md-4 col-lg-2">
                        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-8">
                            <h4>Stock Opname</h4>
                        </a>
                    </li> -->
                    <!-- End Tab 8 Nav -->

                </ul>


                <div class="tab-content">

                    <div class="tab-pane active show" id="tab-1">
                        <div class="row gy-4">
                            <div class="col-lg-6 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="100">
                                <h3>Menu Login</h3>
                                <p class="fst-italic">
                                    Untuk penggunaan pertama kali, default untuk kode pengguna dan kata sandi adalah
                                    "admin".
                                    Isikan nilai User Code dengan `admin` dan Password dengan `admin` juga.
                                </p>
                            </div>
                            <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up"
                                data-aos-delay="200">
                                <img src="assets/img/module/login.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div><!-- End Tab Content 1 -->

                    <div class="tab-pane" id="tab-2">
                        <div class="row gy-4">
                            <div class="col-lg-6 order-2 order-lg-1">
                                <h3>Master Supplier</h3>
                                <p>
                                    Digunakan untuk mencatat semua supplier yang berhubungan dengan perusahaan yang akan
                                    digunakan pada saat pengumpulan data transaksi pembelian.
                                </p>
                            </div>
                            <div class="col-lg-6 order-1 order-lg-2 text-center">
                                <img src="assets/img/module/smartmockups_ms_supplier.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div><!-- End Tab Content 2 -->

                    <div class="tab-pane" id="tab-3">
                        <div class="row gy-4">
                            <div class="col-lg-6 order-2 order-lg-1">
                                <h3>Purchase Order</h3>
                                <p>
                                Purchase Order (PO) digunakan untuk mengelola proses pembelian barang dan jasa dari pemasok (vendor). Modul ini mencakup berbagai fungsi yang membantu perusahaan mengotomatisasi dan mengelola alur kerja pembelian dengan lebih efisien.
                                </p>
                            </div>
                            <div class="col-lg-6 order-1 order-lg-2 text-center">
                                <img src="assets/img/module/smartmockups_po.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div><!-- End Tab Content 3 -->

                    <div class="tab-pane" id="tab-4">
                        <div class="row gy-4">
                            <div class="col-lg-6 order-2 order-lg-1">
                                <h3>Sales Order</h3>
                                <p>
                                Sales Order (SO) digunakan untuk mengelola proses penjualan barang dan jasa kepada pelanggan. Modul ini membantu perusahaan mengotomatisasi dan mengelola alur kerja penjualan dengan lebih efisien dan efektif
                                </p>
                            </div>
                            <div class="col-lg-6 order-1 order-lg-2 text-center">
                                <img src="assets/img/module/smartmockups_so.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div><!-- End Tab Content 4 -->

                    <div class="tab-pane" id="tab-5">
                        <div class="row gy-4">
                            <div class="col-lg-6 order-2 order-lg-1">
                                <h3>Bank Masuk</h3>
                                <p>
                                "Bank Masuk" atau "Bank Receipt" digunakan untuk mengelola penerimaan uang dari berbagai sumber ke dalam akun bank perusahaan. Modul ini membantu perusahaan mengotomatisasi dan mengelola alur kerja penerimaan kas dengan lebih efisien dan akurat.
                                </p>
                            </div>
                            <div class="col-lg-6 order-1 order-lg-2 text-center">
                                <img src="assets/img/module/smartmockups_bank_masuk.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div><!-- End Tab Content 5 -->

                    <div class="tab-pane" id="tab-6">
                        <div class="row gy-4">
                            <div class="col-lg-6 order-2 order-lg-1">
                                <h3>Laporan Keuangan</h3>
                                <p>
                                "Laporan Keuangan" digunakan untuk mengelola dan menganalisis data keuangan perusahaan. Modul ini menyediakan berbagai jenis laporan keuangan yang membantu manajemen dalam pengambilan keputusan, pelaporan kepada pemangku kepentingan, dan pemenuhan kewajiban hukum dan regulasi.
                                </p>
                            </div>
                            <div class="col-lg-6 order-1 order-lg-2 text-center">
                                <img src="assets/img/module/smartmockups_report_keuangan.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div><!-- End Tab Content 6 -->
                
                    <div class="tab-pane" id="tab-7">
                        <div class="row gy-4">
                            <div class="col-lg-6 order-2 order-lg-1">
                                <h3>Menu-menu lainya</h3>
                                <p>
                                   Masih Banyak menu lainya, sesuai Custome dari permintaan Customer.
                                </p>
                                <!-- <p class="fst-italic">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                magna aliqua.
              </p>
              <ul>
                <li><i class="bi bi-check-circle-fill"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                <li><i class="bi bi-check-circle-fill"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                <li><i class="bi bi-check-circle-fill"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
              </ul> -->
                            </div>
                            <div class="col-lg-6 order-1 order-lg-2 text-center">
                                <img src="assets/img/module/smartmockups_absen.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section><!-- End Features Section -->



        <!-- ======= Why Us Section ======= -->
        {{-- <section id="why-us" class="why-us section-bg">
            <div class="container-fluid" data-aos="fade-up">

                <div class="row">

                    <div
                        class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

                        <div class="content">
                            <h3>Eum ipsam laborum deleniti <strong>velit pariatur architecto aut nihil</strong></h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit
                            </p>
                        </div>

                        <div class="accordion-list">
                            <ul>
                                <li>
                                    <a data-bs-toggle="collapse" class="collapse"
                                        data-bs-target="#accordion-list-1"><span>01</span> Non consectetur a erat nam
                                        at lectus urna duis? <i class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-1" class="collapse show"
                                        data-bs-parent=".accordion-list">
                                        <p>
                                            Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus
                                            laoreet non curabitur gravida. Venenatis lectus magna fringilla urna
                                            porttitor rhoncus dolor purus non.
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-2"
                                        class="collapsed"><span>02</span> Feugiat scelerisque varius morbi enim nunc?
                                        <i class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-2" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id
                                            interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus
                                            scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper
                                            dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-3"
                                        class="collapsed"><span>03</span> Dolor sit amet consectetur adipiscing elit?
                                        <i class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-3" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci.
                                            Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet
                                            nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis
                                            convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio
                                            morbi quis
                                        </p>
                                    </div>
                                </li>

                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img"
                        style='background-image: url("assets/img/why-us.png");' data-aos="zoom-in"
                        data-aos-delay="150">&nbsp;</div>
                </div>

            </div>
        </section><!-- End Why Us Section --> --}}

        {{-- <!-- ======= Skills Section ======= -->
        <section id="skills" class="skills">
            <div class="container" data-aos="fade-up">

                <div class="row">
                    <div class="col-lg-6 d-flex align-items-center" data-aos="fade-right" data-aos-delay="100">
                        <img src="assets/img/skills.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-6 pt-4 pt-lg-0 content" data-aos="fade-left" data-aos-delay="100">
                        <h3>Voluptatem dignissimos provident quasi corporis voluptates</h3>
                        <p class="fst-italic">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore
                            magna aliqua.
                        </p>

                        <div class="skills-content">

                            <div class="progress">
                                <span class="skill">HTML <i class="val">100%</i></span>
                                <div class="progress-bar-wrap">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="100"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                            <div class="progress">
                                <span class="skill">CSS <i class="val">90%</i></span>
                                <div class="progress-bar-wrap">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="90"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                            <div class="progress">
                                <span class="skill">JavaScript <i class="val">75%</i></span>
                                <div class="progress-bar-wrap">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="75"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                            <div class="progress">
                                <span class="skill">Photoshop <i class="val">55%</i></span>
                                <div class="progress-bar-wrap">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="55"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>

            </div>
        </section><!-- End Skills Section --> --}}



        <!-- ======= Cta Section ======= -->
        <section id="cta" class="cta">
            <div class="container" data-aos="zoom-in">

                <div class="row">
                    <div class="col-lg-9 text-center text-lg-start">
                        <!-- <h3>Get Involved</h3>
                        <p> Join us in making a difference. Contribute to meaningful projects and be part of our
                            community. Together, we can achieve more and create a better future.</p>
                    </div>
                    <div class="col-lg-3 cta-btn-container text-center">
                        <a class="cta-btn align-middle" href="#">Get Started</a> -->
                    </div>
                </div>

            </div>
        </section><!-- End Cta Section -->

        <!-- ======= Portfolio Section ======= -->
        <!-- <section id="portfolio" class="portfolio">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Portfolio</h2>
                    <p>Temukan berbagai proyek kreatif kami di sini. Setiap proyek memiliki keunikan dan inovasi yang
                        kami
                        tawarkan. Lihat dan temukan inspirasi baru!</p>
                </div>

                <ul id="portfolio-flters" class="d-flex justify-content-center" data-aos="fade-up"
                    data-aos-delay="100">
                    <li data-filter="*" class="filter-active">All</li>
                    <li data-filter=".filter-app">App</li>
                    <li data-filter=".filter-card">Card</li>
                    <li data-filter=".filter-web">Web</li>
                </ul>

                <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

                    <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-1.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>App 1</h4>
                            <p>App</p>
                            <a href="assets/img/portfolio/portfolio-1.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="App 1"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-2.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>Web 3</h4>
                            <p>Web</p>
                            <a href="assets/img/portfolio/portfolio-2.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="Web 3"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-3.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>App 2</h4>
                            <p>App</p>
                            <a href="assets/img/portfolio/portfolio-3.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="App 2"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-4.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>Card 2</h4>
                            <p>Card</p>
                            <a href="assets/img/portfolio/portfolio-4.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="Card 2"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-5.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>Web 2</h4>
                            <p>Web</p>
                            <a href="assets/img/portfolio/portfolio-5.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="Web 2"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-6.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>App 3</h4>
                            <p>App</p>
                            <a href="assets/img/portfolio/portfolio-6.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="App 3"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-7.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>Card 1</h4>
                            <p>Card</p>
                            <a href="assets/img/portfolio/portfolio-7.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="Card 1"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-8.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>Card 3</h4>
                            <p>Card</p>
                            <a href="assets/img/portfolio/portfolio-8.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="Card 3"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-img"><img src="assets/img/portfolio/portfolio-9.jpg" class="img-fluid"
                                alt=""></div>
                        <div class="portfolio-info">
                            <h4>Web 3</h4>
                            <p>Web</p>
                            <a href="assets/img/portfolio/portfolio-9.jpg" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="Web 3"><i class="bx bx-plus"></i></a>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bx bx-link"></i></a>
                        </div>
                    </div>

                </div>

            </div>
        </section> -->
        <!-- End Portfolio Section -->

        <!-- ======= Team Section ======= -->
        {{-- <section id="team" class="team section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Team</h2>
                    <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit
                        sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias
                        ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
                </div>

                <div class="row">

                    <div class="col-lg-6" data-aos="zoom-in" data-aos-delay="100">
                        <div class="member d-flex align-items-start">
                            <div class="pic"><img src="assets/img/team/team-1.jpg" class="img-fluid"
                                    alt=""></div>
                            <div class="member-info">
                                <h4>Walter White</h4>
                                <span>Chief Executive Officer</span>
                                <p>Explicabo voluptatem mollitia et repellat qui dolorum quasi</p>
                                <div class="social">
                                    <a href=""><i class="ri-twitter-fill"></i></a>
                                    <a href=""><i class="ri-facebook-fill"></i></a>
                                    <a href=""><i class="ri-instagram-fill"></i></a>
                                    <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="200">
                        <div class="member d-flex align-items-start">
                            <div class="pic"><img src="assets/img/team/team-2.jpg" class="img-fluid"
                                    alt=""></div>
                            <div class="member-info">
                                <h4>Sarah Jhonson</h4>
                                <span>Product Manager</span>
                                <p>Aut maiores voluptates amet et quis praesentium qui senda para</p>
                                <div class="social">
                                    <a href=""><i class="ri-twitter-fill"></i></a>
                                    <a href=""><i class="ri-facebook-fill"></i></a>
                                    <a href=""><i class="ri-instagram-fill"></i></a>
                                    <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mt-4" data-aos="zoom-in" data-aos-delay="300">
                        <div class="member d-flex align-items-start">
                            <div class="pic"><img src="assets/img/team/team-3.jpg" class="img-fluid"
                                    alt=""></div>
                            <div class="member-info">
                                <h4>William Anderson</h4>
                                <span>CTO</span>
                                <p>Quisquam facilis cum velit laborum corrupti fuga rerum quia</p>
                                <div class="social">
                                    <a href=""><i class="ri-twitter-fill"></i></a>
                                    <a href=""><i class="ri-facebook-fill"></i></a>
                                    <a href=""><i class="ri-instagram-fill"></i></a>
                                    <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mt-4" data-aos="zoom-in" data-aos-delay="400">
                        <div class="member d-flex align-items-start">
                            <div class="pic"><img src="assets/img/team/team-4.jpg" class="img-fluid"
                                    alt=""></div>
                            <div class="member-info">
                                <h4>Amanda Jepson</h4>
                                <span>Accountant</span>
                                <p>Dolorum tempora officiis odit laborum officiis et et accusamus</p>
                                <div class="social">
                                    <a href=""><i class="ri-twitter-fill"></i></a>
                                    <a href=""><i class="ri-facebook-fill"></i></a>
                                    <a href=""><i class="ri-instagram-fill"></i></a>
                                    <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section><!-- End Team Section --> --}}

        {{-- <!-- ======= Pricing Section ======= -->
        <section id="pricing" class="pricing">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Pricing</h2>
                    <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit
                        sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias
                        ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
                </div>

                <div class="row">

                    <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="box">
                            <h3>Free Plan</h3>
                            <h4><sup>$</sup>0<span>per month</span></h4>
                            <ul>
                                <li><i class="bx bx-check"></i> Quam adipiscing vitae proin</li>
                                <li><i class="bx bx-check"></i> Nec feugiat nisl pretium</li>
                                <li><i class="bx bx-check"></i> Nulla at volutpat diam uteera</li>
                                <li class="na"><i class="bx bx-x"></i> <span>Pharetra massa massa ultricies</span>
                                </li>
                                <li class="na"><i class="bx bx-x"></i> <span>Massa ultricies mi quis
                                        hendrerit</span></li>
                            </ul>
                            <a href="#" class="buy-btn">Get Started</a>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
                        <div class="box featured">
                            <h3>Business Plan</h3>
                            <h4><sup>$</sup>29<span>per month</span></h4>
                            <ul>
                                <li><i class="bx bx-check"></i> Quam adipiscing vitae proin</li>
                                <li><i class="bx bx-check"></i> Nec feugiat nisl pretium</li>
                                <li><i class="bx bx-check"></i> Nulla at volutpat diam uteera</li>
                                <li><i class="bx bx-check"></i> Pharetra massa massa ultricies</li>
                                <li><i class="bx bx-check"></i> Massa ultricies mi quis hendrerit</li>
                            </ul>
                            <a href="#" class="buy-btn">Get Started</a>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
                        <div class="box">
                            <h3>Developer Plan</h3>
                            <h4><sup>$</sup>49<span>per month</span></h4>
                            <ul>
                                <li><i class="bx bx-check"></i> Quam adipiscing vitae proin</li>
                                <li><i class="bx bx-check"></i> Nec feugiat nisl pretium</li>
                                <li><i class="bx bx-check"></i> Nulla at volutpat diam uteera</li>
                                <li><i class="bx bx-check"></i> Pharetra massa massa ultricies</li>
                                <li><i class="bx bx-check"></i> Massa ultricies mi quis hendrerit</li>
                            </ul>
                            <a href="#" class="buy-btn">Get Started</a>
                        </div>
                    </div>

                </div>

            </div>
        </section><!-- End Pricing Section --> --}}

        <!-- ======= F.A.Q Section ======= -->
        <section id="faq" class="faq">
            <div class="container-fluid" data-aos="fade-up">

                <div class="row gy-4">

                    <div
                        class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

                        <div class="content px-xl-5">
                            <h3>Frequently Asked Questions<strong>(FAQ)</strong></h3>
                            <!-- <p>
        <strong>SAO itu Sofware apa sih?</strong> SAO (Sale Account Organizer) adalah perangkat lunak manajemen bisnis yang akan membantu Anda menjalankan setiap aspek bisnis Anda. Dari mengelola persediaan hingga menganalisis data, memproses penjualan, dan mengelola data klien, bersama dengan alat akuntansi dan pencatatan yang mudah. SAO akan membantu Anda mengelola setiap aspek jika bisnis Anda dari bawah ke atas
        </p> -->
                        </div>

                        <div class="accordion accordion-flush px-xl-5" id="faqlist">

                            <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                                        <i class="bi bi-question-circle question-icon"></i>
                                        Apa itu SAO (Sale Account Organizer)?
                                    </button>
                                </h3>
                                <div id="faq-content-1" class="accordion-collapse collapse"
                                    data-bs-parent="#faqlist">
                                    <div class="accordion-body">
                                        SAO (Sale Account Organizer) adalah perangkat lunak manajemen bisnis yang
                                        dirancang
                                        untuk membantu pengusaha mengelola berbagai aspek bisnis mereka. Dari manajemen
                                        persediaan hingga analisis data, pemrosesan penjualan, pengelolaan informasi
                                        klien,
                                        hingga alat akuntansi dan pencatatan yang efisien, SAO memberikan solusi lengkap
                                        untuk mengelola bisnis dari bawah ke atas.
                                    </div>
                                </div>
                            </div><!-- # Faq item-->

                            <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                                        <i class="bi bi-question-circle question-icon"></i>
                                        Apa keunggulan utama SAO dalam menjalankan bisnis?
                                    </button>
                                </h3>
                                <div id="faq-content-2" class="accordion-collapse collapse"
                                    data-bs-parent="#faqlist">
                                    <div class="accordion-body">
                                        Salah satu keunggulan utama SAO adalah kemampuannya dalam mengintegrasikan
                                        berbagai
                                        fungsi bisnis menjadi satu platform. Ini memungkinkan Anda untuk dengan mudah
                                        mengontrol persediaan, menghasilkan laporan analisis yang mendalam, serta
                                        mengelola
                                        transaksi penjualan dan keuangan dengan efisien. SAO juga menawarkan alat
                                        pelacakan
                                        klien yang membantu Anda memahami kebutuhan dan preferensi pelanggan.
                                    </div>
                                </div>
                            </div><!-- # Faq item-->

                            <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                                        <i class="bi bi-question-circle question-icon"></i>
                                        Apa manfaat penggunaan SAO bagi pemilik bisnis?
                                    </button>
                                </h3>
                                <div id="faq-content-3" class="accordion-collapse collapse"
                                    data-bs-parent="#faqlist">
                                    <div class="accordion-body">
                                        Penggunaan SAO memberikan beberapa manfaat bagi pemilik bisnis. Dengan SAO, Anda
                                        dapat menghemat waktu dan usaha dalam mengelola inventaris, mengelola data
                                        pelanggan, serta mengawasi kinerja bisnis Anda melalui analisis data yang mudah
                                        diakses. Selain itu, alat akuntansi yang terintegrasi membantu Anda melacak
                                        keuangan
                                        dengan lebih baik.
                                    </div>
                                </div>
                            </div><!-- # Faq item-->

                            <div class="accordion-item" data-aos="fade-up" data-aos-delay="500">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#faq-content-4">
                                        <i class="bi bi-question-circle question-icon"></i>
                                        Apakah SAO cocok untuk jenis bisnis apa saja?
                                    </button>
                                </h3>
                                <div id="faq-content-4" class="accordion-collapse collapse"
                                    data-bs-parent="#faqlist">
                                    <div class="accordion-body">
                                        <i class="bi bi-question-circle question-icon"></i>
                                        Ya, SAO dirancang untuk dapat diadaptasi ke berbagai jenis bisnis, baik itu
                                        ritel,
                                        layanan, atau bahkan bisnis online. Dengan fitur yang dapat disesuaikan, SAO
                                        dapat
                                        digunakan oleh berbagai industri, termasuk restoran, toko retail, agen travel,
                                        dan
                                        lainnya.
                                    </div>
                                </div>
                            </div><!-- # Faq item-->

                            <div class="accordion-item" data-aos="fade-up" data-aos-delay="600">
                                <h3 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#faq-content-5">
                                        <i class="bi bi-question-circle question-icon"></i>
                                        Apakah SAO dapat membantu meningkatkan efisiensi operasional?
                                    </button>
                                </h3>
                                <div id="faq-content-5" class="accordion-collapse collapse"
                                    data-bs-parent="#faqlist">
                                    <div class="accordion-body">
                                        Tentu, SAO dapat signifikan meningkatkan efisiensi operasional bisnis Anda.
                                        Dengan
                                        memudahkan manajemen persediaan, transaksi penjualan yang lancar, serta akses
                                        cepat
                                        ke informasi kinerja bisnis, Anda dapat mengambil keputusan yang lebih baik dan
                                        mengoptimalkan operasional bisnis Anda secara keseluruhan.
                                    </div>
                                </div>
                            </div><!-- # Faq item-->

                        </div>

                    </div>

                    <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img"
                        style='background-image: url("assets/img/why-us.png");'>&nbsp;</div>
                </div>

            </div>
        </section><!-- End F.A.Q Section -->


        <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Contact</h2>
                    <p>Hubungi kami untuk pertanyaan lebih lanjut atau butuh bantuan silahkan kirim pesan!</p>
                </div>

                <div class="row">

                    <div class="col-lg-5 d-flex align-items-stretch">
                        <div class="info">
                            <div class="address">
                                <i class="bi bi-geo-alt"></i>
                                <h4>Location:</h4>
                                <p>Jl. Kartini Raya No.16, RT.13/RW.5, Ps. Baru, Kecamatan Sawah Besar, Kota Jakarta
                                    Pusat, Daerah Khusus Ibukota Jakarta 10710</p>
                            </div>

                            <div class="email">
                                <i class="bi bi-envelope"></i>
                                <h4>Email:</h4>
                                <p>1tech@satu-tech.com</p>
                            </div>

                            <div class="phone">
                                <i class="bi bi-phone"></i>
                                <h4>Call:</h4>
                                <p><strong>WhatsApp</strong> (sales) <a href="https://wa.me/6281274500089">081274500089</a><br></p>
                            </div>

                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.802040827493!2d106.83378437586734!3d-6.15726196035062!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f4459bd72655%3A0xd23ee0aa58216cee!2sPt.%20Satu%20Anugrah%20Solusindo!5e0!3m2!1sid!2sid!4v1704959216326!5m2!1sid!2sid"
                                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>

                    </div>

                    <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
                        <form onsubmit="openEmailClient(event)" role="form" class="php-email-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name">Your Name</label>
                                    <input type="text" name="name" class="form-control" id="name"
                                        required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name">Your Email</label>
                                    <input type="email" class="form-control" name="email" id="email"
                                        required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="name">Subject</label>
                                <input type="text" class="form-control" name="subject" id="subject" required>
                            </div>
                            <div class="form-group">
                                <label for="name">Message</label>
                                <textarea class="form-control" name="message" id="message" rows="10" required></textarea>
                            </div>
                            <div class="my-3">
                                <div class="loading">Loading</div>
                                <div class="sent-message">Your message has been sent. Thank you!</div>
                            </div>
                            <div class="text-center"><button type="submit">Send Message</button></div>
                        </form>
                    </div>

                </div>

            </div>
        </section><!-- End Contact Section -->



    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer">

        <div class="footer-newsletter">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <h4>Join Our Newsletter</h4>
                        <p>Tinggalkan email anda jika ingin mendapatkan informasi terbaru dari kami</p>
                        <form action="" method="post">
                            <input type="email" name="email"><input type="submit" value="Subscribe">
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3 col-md-6 footer-contact">
                        <h3><img src="assets/img/saologo.png" alt="" style="width: 50px;"></h3>
                        <p>
                            Jl. Kartini Raya No.16, RT.13/RW.5, Ps. Baru, <br>
                            Kecamatan Sawah Besar, Kota Jakarta Pusat, <br>
                            Daerah Khusus Ibukota Jakarta 10710 <br><br>
                            <strong>WhatsApp:</strong> (sales) <a href="https://wa.me/6281274500089">081274500089</a><br>
                            <strong>Email:</strong> 1tech@satu-tech.com<br>
                        </p>
                    </div>

                    <div class="col-lg-3 col-md-6 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-3 col-md-6 footer-links">
                        <h4>Our Services</h4>
                        <ul>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-3 col-md-6 footer-links">
                        <h4>Our Social Networks</h4>
                        <p>Connect with us on social media for the latest updates and news about SAO Indonesia.</p>
                        <div class="social-links mt-3">
                            <a href="https://www.instagram.com/saoindonesia/" class="instagram"><i
                                    class="bx bxl-instagram"></i></a>
                            <a href="http://www.satu-tech.com/" class="twitter"><i
                                    class="bx bxl-internet-explorer"></i></a>
                            <!-- <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                            <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                            <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a> -->
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="container footer-bottom clearfix">
            <div class="copyright">
                &copy; Copyright <strong><span>1Tech</span></strong>. All Rights Reserved
            </div>
            <div class="credits">
                <!-- All the links in the footer should remain intact. -->
                <!-- You can delete the links only if you purchased the pro version. -->
                <!-- Licensing information: https://bootstrapmade.com/license/ -->
                <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/ -->
                {{-- Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> --}}
            </div>
        </div>
    </footer><!-- End Footer -->

    <div id="preloader"></div>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <script>
        function openEmailClient(event) {
            event.preventDefault();

            // Ambil nilai dari form fields
            var subject = document.getElementById('subject').value;
            var message = document.getElementById('message').value;

            // Konstruksi URL "mailto" dengan subjek dan isi pesan
            var mailtoLink = "mailto:1tech@satu-tech.com?subject=" + encodeURIComponent(subject) + "&body=" +
                encodeURIComponent(message);

            // Buka aplikasi email pengguna
            window.location.href = mailtoLink;

            // Tampilkan pesan setelah berhasil terkirim
            var sentMessage = document.querySelector('.sent-message');
            sentMessage.style.display = 'block'; // Menampilkan pesan
        }
    </script>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>
