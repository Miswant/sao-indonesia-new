@include('head')
@include('header')
<section id="cta" class="cta">
        <div class="section-header">
          <h2></h2>
          <p></p>
        </div>
      <div class="container" data-aos="zoom-out">
      

        <div class="row g-5">

          <div class="col-lg-6 col-md-6 content d-flex flex-column justify-content-center order-last order-md-first">
          <p><strong>Perusahaan Menengah</strong></p>
            <h3>Pantau secara berkala <em>Mudah</em> laporan bisnis anda</h3>
                  <!-- <p><i class="bi bi-check2"></i> Pegang Kendali bisnis anda kapan saja dan dimana saja. </p>
                  <p><i class="bi bi-check2"></i> Mudah di akses dimanapun. </p> -->
           <a class="cta-btn align-self-start" href="#" onclick="openChat()">Hubungi Kami</a>
          </div>

          <div class="col-lg-6 col-md-6 order-first order-md-last d-flex align-items-center">
            <div class="img">
              <img src="assets/img/skala-bisnis/perusahaan-menengah.jpg" alt="" class="img-fluid">
            </div>
          </div>

        </div>

      </div>
    </section>
@include('footer')
@include('script')